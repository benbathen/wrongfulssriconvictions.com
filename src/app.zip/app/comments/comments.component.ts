// `reactive-form.component.ts`
import { Component, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-comment',
  templateUrl: './comments.component.html',   // ✅ match the real file
  styleUrls: ['./comments.component.sass']  
})
export class CommentComponent {
  private fb = inject(FormBuilder);

  formGroup: FormGroup = this.fb.group({
    firstName: ['', Validators.required],
    lastName: [''],
    email: ['', [Validators.required, Validators.email]],
    address: this.fb.group({
      street: [''],
      city: [''],
    }),
  });

  onSubmit() {
    // Log the form value to the console
    console.warn(this.formGroup.value);
  }
}